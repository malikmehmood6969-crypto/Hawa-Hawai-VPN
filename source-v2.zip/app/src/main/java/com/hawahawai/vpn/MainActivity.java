package com.hawahawai.vpn;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.blinkt.openvpn.api.IOpenVPNAPIService;
import de.blinkt.openvpn.api.IOpenVPNStatusCallback;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_IMPORT = 1001;
    private static final int REQ_API_PERMISSION = 1002;
    private static final int REQ_VPN_PERMISSION = 1003;

    private TextView statusText;
    private TextView detailText;
    private TextView timerText;
    private TextView ipText;
    private Button engineButton;
    private Button importButton;
    private Button connectButton;
    private Button disconnectButton;
    private Button testButton;

    private IOpenVPNAPIService vpnApi;
    private boolean apiReady = false;
    private boolean serviceBound = false;
    private boolean connected = false;

    private String configText;
    private String configName;
    private Uri configUri;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private long connectedAt = 0L;

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (!connected || connectedAt == 0L) {
                timerText.setText("00:00:00");
                return;
            }
            long sec = (System.currentTimeMillis() - connectedAt) / 1000L;
            long h = sec / 3600L;
            long m = (sec % 3600L) / 60L;
            long s = sec % 60L;
            timerText.setText(String.format(Locale.US, "%02d:%02d:%02d", h, m, s));
            handler.postDelayed(this, 1000L);
        }
    };

    private final IOpenVPNStatusCallback statusCallback = new IOpenVPNStatusCallback.Stub() {
        @Override
        public void newStatus(String uuid, String state, String message, String level) {
            runOnUiThread(() -> applyVpnStatus(state, message, level));
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            vpnApi = IOpenVPNAPIService.Stub.asInterface(service);
            serviceBound = true;
            statusText.setText("VPN engine found");
            detailText.setText("Authorizing Hawa Hawai...");
            requestApiPermission();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            apiReady = false;
            vpnApi = null;
            statusText.setText("VPN engine disconnected");
            detailText.setText("OpenVPN for Android is not available");
            refreshButtons();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        detailText = findViewById(R.id.detailText);
        timerText = findViewById(R.id.timerText);
        ipText = findViewById(R.id.ipText);
        engineButton = findViewById(R.id.engineButton);
        importButton = findViewById(R.id.importButton);
        connectButton = findViewById(R.id.connectButton);
        disconnectButton = findViewById(R.id.disconnectButton);
        testButton = findViewById(R.id.testButton);

        engineButton.setOnClickListener(v -> openOrInstallEngine());
        importButton.setOnClickListener(v -> chooseProfile());
        connectButton.setOnClickListener(v -> prepareAndConnect());
        disconnectButton.setOnClickListener(v -> disconnectVpn());
        testButton.setOnClickListener(v -> testInternet());

        String savedUri = getPreferences(MODE_PRIVATE).getString("config_uri", null);
        if (savedUri != null) {
            try {
                configUri = Uri.parse(savedUri);
                loadProfile(configUri, false);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        bindVpnEngine();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (vpnApi != null && apiReady) {
            try {
                vpnApi.unregisterStatusCallback(statusCallback);
            } catch (Exception ignored) {
            }
        }
        if (serviceBound) {
            try {
                unbindService(connection);
            } catch (Exception ignored) {
            }
        }
        serviceBound = false;
        apiReady = false;
        vpnApi = null;
    }

    private void bindVpnEngine() {
        Intent serviceIntent = new Intent(IOpenVPNAPIService.class.getName());
        serviceIntent.setPackage("de.blinkt.openvpn");
        boolean ok;
        try {
            ok = bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE);
        } catch (Exception e) {
            ok = false;
        }
        if (!ok) {
            statusText.setText("OpenVPN engine required");
            detailText.setText("Install “OpenVPN for Android” once, then return here.");
            refreshButtons();
        }
    }

    private void requestApiPermission() {
        if (vpnApi == null) return;
        try {
            Intent permission = vpnApi.prepare(getPackageName());
            if (permission != null) {
                startActivityForResult(permission, REQ_API_PERMISSION);
            } else {
                onApiReady();
            }
        } catch (RemoteException e) {
            showError("Engine authorization failed");
        }
    }

    private void onApiReady() {
        apiReady = true;
        try {
            vpnApi.registerStatusCallback(statusCallback);
        } catch (RemoteException ignored) {
        }
        statusText.setText(configText == null ? "Ready" : "Profile ready");
        detailText.setText(configText == null
                ? "Import an OpenVPN TCP .ovpn profile."
                : configName + " • OpenVPN TCP");
        refreshButtons();
    }

    private void chooseProfile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/x-openvpn-profile",
                "text/plain",
                "application/octet-stream"
        });
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void loadProfile(Uri uri, boolean showToast) {
        executor.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 BufferedReader br = new BufferedReader(
                         new InputStreamReader(in, StandardCharsets.UTF_8))) {

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append('\n');
                }

                String content = sb.toString();
                if (!looksLikeOpenVpn(content)) {
                    throw new IllegalArgumentException("This does not look like an OpenVPN profile");
                }

                String name = displayName(uri);
                boolean tcp = isTcpProfile(content);

                runOnUiThread(() -> {
                    configText = content;
                    configName = name == null ? "OpenVPN profile" : name;
                    configUri = uri;
                    getPreferences(MODE_PRIVATE).edit()
                            .putString("config_uri", uri.toString())
                            .apply();

                    statusText.setText(tcp ? "Profile ready" : "TCP profile required");
                    detailText.setText(tcp
                            ? configName + " • TCP detected"
                            : configName + " uses UDP or has no TCP protocol line.");
                    if (showToast) {
                        toast(tcp ? "OpenVPN TCP profile imported" : "Please use a TCP .ovpn profile");
                    }
                    refreshButtons();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    configText = null;
                    configName = null;
                    statusText.setText("Profile import failed");
                    detailText.setText(safeMessage(e));
                    refreshButtons();
                });
            }
        });
    }

    private boolean looksLikeOpenVpn(String c) {
        String s = c.toLowerCase(Locale.US);
        return s.contains("client") && s.contains("remote ") && (s.contains("dev tun") || s.contains("dev-type tun"));
    }

    private boolean isTcpProfile(String c) {
        String[] lines = c.split("\\r?\\n");
        for (String raw : lines) {
            String line = raw.trim().toLowerCase(Locale.US);
            if (line.startsWith("#") || line.startsWith(";")) continue;
            if (line.equals("proto tcp")
                    || line.equals("proto tcp-client")
                    || line.startsWith("proto tcp4")
                    || line.startsWith("proto tcp6")) {
                return true;
            }
        }
        return false;
    }

    private void prepareAndConnect() {
        if (vpnApi == null || !apiReady) {
            toast("OpenVPN engine is not ready");
            return;
        }
        if (configText == null || !isTcpProfile(configText)) {
            toast("Import a TCP .ovpn profile first");
            return;
        }
        try {
            Intent permission = vpnApi.prepareVPNService();
            if (permission != null) {
                startActivityForResult(permission, REQ_VPN_PERMISSION);
            } else {
                startVpnNow();
            }
        } catch (RemoteException e) {
            showError("Could not request VPN permission");
        }
    }

    private void startVpnNow() {
        try {
            statusText.setText("Connecting...");
            detailText.setText(configName == null ? "OpenVPN TCP" : configName);
            connectButton.setEnabled(false);
            vpnApi.startVPN(configText);
        } catch (RemoteException e) {
            showError("Could not start VPN");
        }
    }

    private void disconnectVpn() {
        if (vpnApi == null) return;
        try {
            vpnApi.disconnect();
            statusText.setText("Disconnecting...");
        } catch (RemoteException e) {
            showError("Could not disconnect VPN");
        }
    }

    private void applyVpnStatus(String state, String message, String level) {
        String s = state == null ? "" : state.toUpperCase(Locale.US);
        String m = (message == null || message.trim().isEmpty()) ? state : message;

        boolean nowConnected = s.contains("CONNECTED") && !s.contains("DISCONNECTED");
        boolean nowDisconnected =
                s.contains("NOPROCESS")
                || s.contains("DISCONNECTED")
                || s.contains("EXITING")
                || s.contains("NOTCONNECTED");

        if (nowConnected && !connected) {
            connected = true;
            connectedAt = System.currentTimeMillis();
            handler.removeCallbacks(timerRunnable);
            handler.post(timerRunnable);
        } else if (nowDisconnected) {
            connected = false;
            connectedAt = 0L;
            handler.removeCallbacks(timerRunnable);
            timerText.setText("00:00:00");
        }

        if (nowConnected) {
            statusText.setText("Connected");
        } else if (s.contains("AUTH")) {
            statusText.setText("Authentication");
        } else if (s.contains("WAIT") || s.contains("CONNECT")) {
            statusText.setText("Connecting...");
        } else if (nowDisconnected) {
            statusText.setText("Disconnected");
        } else if (state != null && !state.isEmpty()) {
            statusText.setText(state);
        }

        detailText.setText(m == null ? "" : m);
        refreshButtons();
    }

    private void refreshButtons() {
        boolean tcpOk = configText != null && isTcpProfile(configText);
        connectButton.setEnabled(apiReady && tcpOk && !connected);
        disconnectButton.setEnabled(apiReady && connected);
        importButton.setEnabled(!connected);
    }

    private void testInternet() {
        ipText.setText("Testing internet...");
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://api.ipify.org");
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                conn.setRequestMethod("GET");
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String ip = br.readLine();
                    runOnUiThread(() -> ipText.setText("Public IP: " + ip + " ✓"));
                }
            } catch (Exception e) {
                runOnUiThread(() -> ipText.setText("Internet test failed ✕"));
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void openOrInstallEngine() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("de.blinkt.openvpn");
            if (launch != null) {
                startActivity(launch);
                return;
            }
        } catch (Exception ignored) {
        }

        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=de.blinkt.openvpn")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=de.blinkt.openvpn")));
        }
    }

    private @Nullable String displayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void showError(String msg) {
        statusText.setText("Error");
        detailText.setText(msg);
        toast(msg);
        refreshButtons();
    }

    private String safeMessage(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_IMPORT && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            loadProfile(uri, true);
            return;
        }

        if (requestCode == REQ_API_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
                onApiReady();
            } else {
                statusText.setText("Permission required");
                detailText.setText("Allow Hawa Hawai to control the OpenVPN engine.");
            }
            return;
        }

        if (requestCode == REQ_VPN_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
                startVpnNow();
            } else {
                toast("Android VPN permission is required");
            }
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(timerRunnable);
        executor.shutdown();
        super.onDestroy();
    }
}
