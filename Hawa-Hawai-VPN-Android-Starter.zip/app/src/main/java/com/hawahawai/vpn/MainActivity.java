package com.hawahawai.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_IMPORT = 2001;
    private static final int REQUEST_VPN = 2002;
    private TextView statusText, configText;
    private Button importButton, connectButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private GoBackend backend;
    private Config config;
    private SimpleTunnel tunnel;
    private boolean connected = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText=findViewById(R.id.statusText); configText=findViewById(R.id.configText);
        importButton=findViewById(R.id.importButton); connectButton=findViewById(R.id.connectButton);
        backend=new GoBackend(getApplicationContext()); tunnel=new SimpleTunnel("hawahawai");
        importButton.setOnClickListener(v->openConfigPicker());
        connectButton.setOnClickListener(v->{ if(config==null){toast("Import a valid WireGuard .conf file first");return;} if(connected) disconnectTunnel(); else requestVpnPermissionAndConnect(); });
    }

    private void openConfigPicker(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","application/octet-stream"}); startActivityForResult(i,REQUEST_IMPORT); }
    private void requestVpnPermissionAndConnect(){ Intent i=VpnService.prepare(this); if(i!=null) startActivityForResult(i,REQUEST_VPN); else connectTunnel(); }
    private void connectTunnel(){ setBusy("Connecting..."); executor.execute(()->{ try{ backend.setState(tunnel,Tunnel.State.UP,config); runOnUiThread(()->updateConnectedUi(true)); } catch(Exception e){ runOnUiThread(()->{updateConnectedUi(false);toast("Connection failed: "+safeMessage(e));}); }}); }
    private void disconnectTunnel(){ setBusy("Disconnecting..."); executor.execute(()->{ try{ backend.setState(tunnel,Tunnel.State.DOWN,null); runOnUiThread(()->updateConnectedUi(false)); } catch(Exception e){ runOnUiThread(()->{updateConnectedUi(connected);toast("Disconnect failed: "+safeMessage(e));}); }}); }
    private void setBusy(String m){statusText.setText(m);connectButton.setEnabled(false);importButton.setEnabled(false);}
    private void updateConnectedUi(boolean c){connected=c;statusText.setText(c?"Connected":(config!=null?"Ready to connect":"No WireGuard config imported"));connectButton.setText(c?"Disconnect":"Connect");connectButton.setEnabled(config!=null);importButton.setEnabled(!c);}
    private void loadConfig(Uri uri){ executor.execute(()->{ try(InputStream in=getContentResolver().openInputStream(uri)){ if(in==null) throw new IllegalArgumentException("Could not open selected file"); config=Config.parse(in); String n=getDisplayName(uri); runOnUiThread(()->{configText.setText(n!=null?n:"WireGuard configuration loaded");statusText.setText("Ready to connect");connectButton.setEnabled(true);toast("Config imported");}); } catch(Exception e){ runOnUiThread(()->{config=null;connectButton.setEnabled(false);statusText.setText("Invalid configuration");toast("Could not import config: "+safeMessage(e));}); }}); }
    private @Nullable String getDisplayName(Uri uri){ try(Cursor c=getContentResolver().query(uri,null,null,null,null)){ if(c!=null&&c.moveToFirst()){int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(idx>=0)return c.getString(idx);} }catch(Exception ignored){} return null; }
    @Override protected void onActivityResult(int requestCode,int resultCode,@Nullable Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==REQUEST_IMPORT&&resultCode==Activity.RESULT_OK&&data!=null&&data.getData()!=null) loadConfig(data.getData()); else if(requestCode==REQUEST_VPN){ if(resultCode==Activity.RESULT_OK) connectTunnel(); else toast("VPN permission is required"); }}
    private String safeMessage(Exception e){return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
    private void toast(String m){Toast.makeText(this,m,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
    private final class SimpleTunnel implements Tunnel{ private final String name; SimpleTunnel(String n){name=n;} public String getName(){return name;} public void onStateChange(State s){runOnUiThread(()->updateConnectedUi(s==State.UP));} }
}
